#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "boost/thread.hpp"
#include <Eigen/Eigen>
#include "gazebo_msgs/ModelStates.h"
#include "std_msgs/Float32MultiArray.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Float64MultiArray.h"
#include <mav_msgs/Actuators.h>
#include "tf/tf.h"
#include <Eigen/Geometry>


class  LAYER{

    public:
        LAYER();
        void Leecallback(const std_msgs::Float64MultiArray lee_motor);
        void Bicallback(const std_msgs::Float64MultiArray bi_motor); 
        void Neuralcallback(const std_msgs::Float32 neural_net);      
	    void main();       
	    void run();

    private:
        Eigen::Vector4d _lee_vel;
        Eigen::Vector4d _bi_vel;
        double nn;

        ros::NodeHandle _nh;
        ros::Subscriber _lee_sub;
        ros::Subscriber _bi_sub;
        ros::Subscriber _nn_sub;
        ros::Publisher _actuators_pub;
        bool _first_odom;
	bool fault;
	

};
