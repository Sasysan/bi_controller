#include "main.h"
#include<math.h>
#include <mav_msgs/default_topics.h>

using namespace std;
using namespace Eigen;

LAYER::LAYER(): _first_odom(false) {
    
    _lee_sub  = _nh.subscribe("/motor_vel",0,&LAYER::Leecallback,this);
    _bi_sub =  _nh.subscribe("/act_motor",0,&LAYER::Bicallback,this);
    _nn_sub = _nh.subscribe("/neural_net",0,&LAYER::Neuralcallback,this);
    _actuators_pub= _nh.advertise<mav_msgs::Actuators>( "/hummingbird/command/motor_speed", 1);
}

void  LAYER::Leecallback(const std_msgs::Float64MultiArray lee_motor){
    _first_odom=true;
    _lee_vel<<lee_motor.data[0],lee_motor.data[1],lee_motor.data[2],lee_motor.data[3];
    }
    
    
void LAYER::Bicallback(const std_msgs::Float64MultiArray bi_motor){
    _bi_vel<<bi_motor.data[0],bi_motor.data[1],bi_motor.data[2],bi_motor.data[3];
    }

void LAYER::Neuralcallback(const std_msgs::Float32 nn_msg){
    nn=nn_msg.data;
    }

void LAYER::main(){

    mav_msgs::Actuators actuator_msg;
    actuator_msg.angular_velocities.clear();
    double tempo=0.0;
    double tempo2=0.0;
    double K=15;
    double K2=0.5;
    double broke=0.0;
    double broke2=0.0;
    double unbroke=0.0;
    double currtime;
    Eigen::Vector4d motor_vel;
    
    ros::Rate rate(100);
    while(ros::ok()){
        currtime = ros::Time::now().toSec();
       actuator_msg.header.stamp = ros::Time::now();
       if(_first_odom==0){
           actuator_msg.angular_velocities={0.0,0.0,0.0,0.0};
       }
        else{
             
            if(nn==2 || nn==4 ||currtime>=32){
                     tempo=tempo+0.01;
                     tempo=tempo;
                     broke=exp(-K*tempo);
                     unbroke=-exp(-K*tempo)+1;

                     _lee_vel=_lee_vel*broke;
                     _bi_vel=_bi_vel*unbroke;
                     motor_vel<<_lee_vel(0)+_bi_vel(0),_lee_vel(1)+_bi_vel(1),_lee_vel(2)+_bi_vel(2),_lee_vel(3)+_bi_vel(3);
                     //motor_vel<<_bi_vel(0),_bi_vel(1),_bi_vel(2),_bi_vel(3);
                     actuator_msg.angular_velocities={motor_vel[0],motor_vel[1],motor_vel[2],motor_vel[3]};

            }
            else{
                    if(currtime>=30 ){
                        tempo2=tempo2+0.01;
                        tempo2=tempo2;
                        broke2=exp(-K2*tempo2);
               
                        actuator_msg.angular_velocities={_lee_vel[0],_lee_vel[1]*broke2,_lee_vel[2],_lee_vel[3]};
                        //actuator_msg.angular_velocities={_bi_vel[0],_bi_vel[1],_bi_vel[2],_bi_vel[3]};
           
                        }
                    else{
                            actuator_msg.angular_velocities={_lee_vel[0],_lee_vel[1],_lee_vel[2],_lee_vel[3]};
                        }
            }
        
        }
        //cout<<"Log= "<<unbroke<<endl;
        //cout<<"Exp= "<<broke<<endl;
        cout<<"Messaggio="<<actuator_msg;
        _actuators_pub.publish(actuator_msg);

        
       
       

        rate.sleep();
        ros::spinOnce();
    }

} 

void LAYER::run(){
    main();
    ros::spin();
}

int main(int argc,char** argv){
ros::init(argc,argv,"layer");
LAYER ly;
ly.run();
return 0;
}