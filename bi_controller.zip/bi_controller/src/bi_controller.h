#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "boost/thread.hpp"
#include <Eigen/Eigen>
#include "gazebo_msgs/ModelStates.h"
#include "std_msgs/Float64MultiArray.h"
#include "std_msgs/Float32.h"
#include "tf/tf.h"
#include <Eigen/Geometry>
#include <mav_msgs/eigen_mav_msgs.h>
#include <nav_msgs/Odometry.h>
#include <mav_msgs/Actuators.h>
#include <mav_msgs/AttitudeThrust.h>

class BI_CONTROLLER{

    public:
        BI_CONTROLLER();
        void position_control();
        void roll_control();
        void input();
        void Odomcallback(const nav_msgs::Odometry odometry_msg);
        void NNcallback(const std_msgs::Float32 neural_net);     
	void run();
        
    private:
        Eigen::Matrix3d _kp_d;
        Eigen::Matrix3d _kd_d;
        Eigen::Matrix3d _ki_d;
	Eigen::Matrix3d R_e2n;
        Eigen::Vector3d _pos;
        Eigen::Vector3d _pos_ned;
        Eigen::Vector3d _vel;
        Eigen::Vector3d _vel_ned;
        Eigen::Vector3d _acc;
        Eigen::Vector3d _eta;
        Eigen::Vector3d _eta_dot;
        Eigen::Vector3d _mu;
        Eigen::Vector3d p_des;
        Eigen::Vector3d v_des;
        Eigen::Vector3d acc_des;
	Eigen::Vector4d ref_rotor_vel;
        Eigen::Vector3d err_p;
        Eigen::Vector3d err_p_i;
        Eigen::Vector3d err_p_i_temp;
        Eigen::Vector3d err_v;
        Eigen::Vector3d p_initial;
        Eigen::Vector3d pos_fin;
        Eigen::Vector3d pos_des;
        double pos_des_z;
        double time;
        double _mass;
        double _gravity;
        double _thrust;
        double _tau;
        double _tau_hat;
        double _pitch_d;
	double pitch;
        double yaw;
	double _kp_pitch;
        double _kd_pitch;
        double _ki_pitch;
        bool _first_odom;
        bool broke;
        double nn;
	double tau_roll;
        double ct;
        double cq;
        double err_p_p;
        double err_p_v;
        double err_p_p_i;
        

        ros::NodeHandle _nh;
        ros::Subscriber _odom_sub;
        ros::Subscriber _nn_sub;
        ros::Publisher _motor_vel_pub;
        ros::Publisher _error_pub;
        //ros::Publisher _motor_velocity_pub;
        nav_msgs::Odometry _odom;
};
