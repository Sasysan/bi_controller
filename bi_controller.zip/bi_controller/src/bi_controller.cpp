#include "bi_controller.h"
#include<math.h>
#include <mav_msgs/default_topics.h>

using namespace std;
using namespace Eigen;



//---Helper functions 
Matrix3d QuatToMat(Vector4d Quat){
    Matrix3d Rot;
    float s = Quat[0];
    float x = Quat[1];
    float y = Quat[2];
    float z = Quat[3];
    Rot << 1-2*(y*y+z*z),2*(x*y-s*z),2*(x*z+s*y),
    2*(x*y+s*z),1-2*(x*x+z*z),2*(y*z-s*x),
    2*(x*z-s*y),2*(y*z+s*x),1-2*(x*x+y*y);
    return Rot;
}

Vector4d rot2quat(Matrix3d R){
    float m00, m01, m02, m10, m11, m12, m20, m21, m22;

    m00 = R(0,0);
    m01 = R(0,1);
    m02 = R(0,2);
    m10 = R(1,0);
    m11 = R(1,1);
    m12 = R(1,2);
    m20 = R(2,0);
    m21 = R(2,1);
    m22 = R(2,2);

    float tr = m00 + m11 + m22;
    float qw, qx, qy, qz, S;
    Vector4d quat;

    if (tr > 0) { 
        S = sqrt(tr+1.0) * 2; // S=4*qw 
        qw = 0.25 * S;
        qx = (m21 - m12) / S;
        qy = (m02 - m20) / S; 
        qz = (m10 - m01) / S; 
    } else if ((m00 > m11)&(m00 > m22)) { 
        S = sqrt(1.0 + m00 - m11 - m22) * 2; // S=4*qx 
        qw = (m21 - m12) / S;
        qx = 0.25 * S;
        qy = (m01 + m10) / S; 
        qz = (m02 + m20) / S; 
    } else if (m11 > m22) { 
        S = sqrt(1.0 + m11 - m00 - m22) * 2; // S=4*qy
        qw = (m02 - m20) / S;
        qx = (m01 + m10) / S; 
        qy = 0.25 * S;
        qz = (m12 + m21) / S; 
    } else { 
        S = sqrt(1.0 + m22 - m00 - m11) * 2; // S=4*qz
        qw = (m10 - m01) / S;
        qx = (m02 + m20) / S;
        qy = (m12 + m21) / S;
        qz = 0.25 * S;
    }

    quat << qw, qx, qy, qz;
    return quat;
}
	
	
Vector3d R2XYZ(Matrix3d R) {
    double phi=0.0, theta=0.0, psi=0.0;
    Vector3d XYZ = Vector3d::Zero();
    
    theta = asin(R(0,2));
    
    if(fabsf(cos(theta))>pow(10.0,-10.0))
    {
        phi=atan2(-R(1,2)/cos(theta), R(2,2)/cos(theta));
        psi=atan2(-R(0,1)/cos(theta), R(0,0)/cos(theta));
    }
    else
    {
        if(fabsf(theta-M_PI/2.0)<pow(10.0,-5.0))
        {
            psi = 0.0;
            phi = atan2(R(1,0), R(2,0));
            theta = M_PI/2.0;
        }
        else
        {
            psi = 0.0;
            phi = atan2(-R(1,0), R(2,0));
            theta = -M_PI/2.0;
        }
    }
    
    XYZ << phi,theta,psi;
    return XYZ;
}

Matrix3d XYZ2R(Vector3d angles) {
    
    Matrix3d R = Matrix3d::Zero(); 
    Matrix3d R1 = Matrix3d::Zero(); 
    Matrix3d R2 = Matrix3d::Zero(); 
    Matrix3d R3 = Matrix3d::Zero();

    float cos_phi = cos(angles[0]);
    float sin_phi = sin(angles[0]);
    float cos_theta = cos(angles[1]);
    float sin_theta = sin(angles[1]);
    float cos_psi = cos(angles[2]);
    float sin_psi = sin(angles[2]);

    R1  << 1, 0      , 0, 
                0, cos_phi, -sin_phi, 
                0, sin_phi, cos_phi;

    R2  << cos_theta , 0, sin_theta, 
                0        , 1, 0       , 
                -sin_theta, 0, cos_theta;

    R3  << cos_psi, -sin_psi, 0, 
                sin_psi, cos_psi , 0,
                0      , 0       , 1;

    R = R1*R2*R3;

    return R;
}
// Fine funzioni aiuto





//_motor_vel_pub = _nh.advertise<mav_msgs::Actuators>( mav_msgs::default_topics::COMMAND_ACTUATORS, 1);
BI_CONTROLLER::BI_CONTROLLER(): _first_odom(false),broke(false){
        
        if( !_nh.getParam("kp_pitch", _kp_pitch) ) {
            _kp_pitch = 1.0;
        }
        
         if( !_nh.getParam("kd_pitch", _kd_pitch) ) {
            _kd_pitch = 1.0;
        }
         if( !_nh.getParam("ki_pitch", _ki_pitch) ) {
            _ki_pitch = 1.0;
        }

        vector<double> kp_d;
    if( !_nh.getParam("kp_d", kp_d) ) {
        kp_d.resize(3);
        kp_d[0] = 1.0;
        kp_d[1] = 1.0;
        kp_d[2] = 1.0;
    }
    _kp_d = Eigen::Matrix3d( Eigen::Vector3d( kp_d[0], kp_d[1], kp_d[2] ).asDiagonal() );
    
       vector<double> kd_d;
    if( !_nh.getParam("kd_d", kd_d) ) {
        kd_d.resize(3);
        kd_d[0] = 1.0;
        kd_d[1] = 1.0;
        kd_d[2] = 1.0;
    _kd_d = Eigen::Matrix3d( Eigen::Vector3d( kd_d[0], kd_d[1], kd_d[2] ).asDiagonal() );    
    
        vector<double> ki_d;
    if( !_nh.getParam("ki_d", ki_d) ) {
        ki_d.resize(3);
        ki_d[0] = 1.0;
        ki_d[1] = 1.0;
        ki_d[2] = 1.0;
    }
    _ki_d = Eigen::Matrix3d( Eigen::Vector3d( kp_d[0], kp_d[1], kp_d[2] ).asDiagonal() );
    }
    
   

        _odom_sub=_nh.subscribe ("/hummingbird/ground_truth/odometry",0,&BI_CONTROLLER::Odomcallback,this);
        _motor_vel_pub=_nh.advertise<std_msgs::Float64MultiArray>("/act_motor",1);
        _error_pub=_nh.advertise<std_msgs::Float64MultiArray>("/error",1);
        _nn_sub=_nh.subscribe ("/neural_net",0,&BI_CONTROLLER::NNcallback,this);
        _mass=0.736;//1.534; massa iris
        _gravity=9.81;
        ct=8.54858e-06;
        cq=8.54858e-06*0.016;
        p_initial<<0,0,-3;
        err_p_i<<0.0,0.0,0.0;
        err_p_i_temp<<0.0,0.0,0.0;
        err_p_p_i=0.0;
        err_p<<0.0,0.0,0.0;
        err_p_p=0.0;
       

}

void BI_CONTROLLER::Odomcallback(const nav_msgs::Odometry odometry_msg){
   
    _odom= odometry_msg;
    _first_odom=true;
    R_e2n<<0,1,0,1,0,0,0,0,-1;
    _pos<<_odom.pose.pose.position.x, _odom.pose.pose.position.y, _odom.pose.pose.position.z; 
    _pos_ned=R_e2n*_pos;
    _eta = R2XYZ( QuatToMat ( Vector4d( _odom.pose.pose.orientation.w,  _odom.pose.pose.orientation.x, _odom.pose.pose.orientation.y, _odom.pose.pose.orientation.z ) ) );
    _eta=R_e2n*_eta;
    _eta_dot<<_odom.twist.twist.angular.x,_odom.twist.twist.angular.y,_odom.twist.twist.angular.z;
    _eta_dot=R_e2n*_eta_dot;
    _vel<<_odom.twist.twist.linear.x,_odom.twist.twist.linear.y,_odom.twist.twist.linear.z;
    _vel_ned=R_e2n*_vel;
    
}

void BI_CONTROLLER::NNcallback(const std_msgs::Float32 neural_net){
    nn=neural_net.data;
}

void BI_CONTROLLER::position_control(){
    //while(!_first_odom) usleep(0.1e6);
    double K=0.5;
    if (nn==2 && !broke){
        p_initial<<_pos_ned(0),_pos_ned(1),_pos_ned(2);
        broke=true;
    }
    double dt=1.0/100.0;
    pos_fin<<p_initial(0),p_initial(1),0.5;
    if(broke){
        time=time+0.01;
        time=time;
        pos_des_z=p_initial(2)+((pos_fin(2)-p_initial(2))*(-exp(-K*time)+1));
        p_des<<p_initial(0),p_initial(1),pos_des_z;
    }
    else{
        p_des<<p_initial(0),p_initial(1),p_initial(2);
    }
    v_des<<0.0,0.0,0.0;
    acc_des<<0.0,0.0,0.0;
    
    //err_p=p_des-_pos_ned;
    err_p=p_initial-_pos_ned;
    err_v=v_des-_vel_ned;
    //errore integrale
    err_p_i=err_p_i_temp+(err_p*(1.0/100.0));
    err_p_i_temp=err_p_i;
    
    
    _mu=acc_des+_kp_d*err_p+_kd_d*err_v+_ki_d*err_p_i;
    
    double thrust_temp;
    thrust_temp=((_mu(0)*_mu(0))+(_mu(1)*_mu(1))+((_mu(2)-_gravity)*(_mu(2)-_gravity)));
    
    _thrust=_mass*(sqrt(thrust_temp));
    
    //double roll_temp=((_mass*((_mu(1)*cos(_eta(2)))-(_mu(0)*sin(_eta(2)))))/_thrust);
    double pitch_temp_y=(_mu(0)*cos(_eta(2)))+(_mu(1)*sin(_eta(2)));
    double pitch_temp_x=_mu(2)-_gravity;
    _pitch_d=atan(pitch_temp_y/pitch_temp_x);
    //_pitch_d=atan2(pitch_temp_y,pitch_temp_x);
    //saturazione
    //if(_pitch_d>(M_PI*10)/180)
    //    _pitch_d=(M_PI*10)/180;
    //else if (_pitch_d<(-M_PI*10)/180)
    //    _pitch_d=(-M_PI*10)/180;    
    //cout<<"P_des="<<p_des<<endl;
    //cout<<"Err_p_i="<<err_p_i<<endl;
    
    //cout<<"Err_p="<<err_p<<endl;
    cout<<"Thrust="<<_thrust<<endl;
    cout<<"Pitch_d="<<_pitch_d<<endl;
    
};

void BI_CONTROLLER::roll_control(){
    
    double err_p_p_i_temp=0.0;
    double pitch_dd_temp=0.0;
    double pitch_d_temp=0.0;
    double delta= 1.0/100.0;
    double pitch_dd;
    pitch_dd=(_pitch_d-pitch_d_temp)*delta;
    pitch_d_temp=_pitch_d;
    
    double pitch_ddd;
    pitch_ddd=(pitch_dd-pitch_dd_temp)*delta;
    pitch_dd_temp=pitch_dd;
   
    //cout<<"Roll_d="<<_roll_d<<endl;
    //cout<<"Roll_dd="<<roll_dd<<endl;
    //cout<<"Roll_ddd="<<roll_ddd<<endl;
    //cout<<"Kp_pitch="<<_kp_pitch<<endl;
    //cout<<"Kd_pitch="<<_kd_pitch<<endl;
    err_p_p=_pitch_d-_eta(1);
    err_p_v=pitch_dd-_eta_dot(1);
    //errore integrale
    err_p_p_i=err_p_p_i_temp+(err_p_p*(1.0/100.0));
    err_p_p_i_temp=err_p_p_i;
    
    _tau_hat=pitch_ddd+_kd_pitch*err_p_v+err_p_p*_kp_pitch+err_p_p_i*_ki_pitch;

    double Ix=0.007;
    double Iy=0.007;
    double Iz=0.012;
    double alpha_1=0.0;
    double alpha_2=0.0;
    double alpha_3=0.0;
    double tau_hat_yaw=(cq*_thrust)/(ct);

    alpha_3=-Ix*_eta_dot(0)*_eta_dot(1)*sin(_eta(0))
            -Iy*_eta_dot(0)*_eta_dot(1)*sin(_eta(0))
            +Iz*_eta_dot(0)*_eta_dot(1)*sin(_eta(0))
            -Ix*_eta_dot(2)*_eta_dot(2)*cos(_eta(0))*cos(_eta(1))*sin(_eta(1))
            +Iz*_eta_dot(2)*_eta_dot(2)*cos(_eta(0))*cos(_eta(1))*sin(_eta(1))
            +Ix*_eta_dot(0)*_eta_dot(2)*cos(_eta(0))*cos(_eta(1))
            +Iy*_eta_dot(0)*_eta_dot(2)*cos(_eta(0))*cos(_eta(1))
            -Iz*_eta_dot(0)*_eta_dot(2)*cos(_eta(0))*cos(_eta(1))
            +Ix*_eta_dot(2)*_eta_dot(1)*sin(_eta(0))*sin(_eta(1))
            -Iy*_eta_dot(2)*_eta_dot(1)*sin(_eta(0))*sin(_eta(1))
            -Iz*_eta_dot(2)*_eta_dot(1)*sin(_eta(0))*sin(_eta(1));

    alpha_2=-Ix*_eta_dot(0)*_eta_dot(1)*cos(_eta(0))
            +Iy*_eta_dot(0)*_eta_dot(1)*cos(_eta(0))
            -Iz*_eta_dot(0)*_eta_dot(1)*cos(_eta(0))
            +Ix*_eta_dot(2)*_eta_dot(2)*cos(_eta(1))*sin(_eta(0))*sin(_eta(1))
            -Iy*_eta_dot(2)*_eta_dot(2)*cos(_eta(1))*sin(_eta(0))*sin(_eta(1))
            -Ix*_eta_dot(0)*_eta_dot(2)*cos(_eta(1))*sin(_eta(0))
            +Iy*_eta_dot(0)*_eta_dot(2)*cos(_eta(1))*sin(_eta(0))
            -Iz*_eta_dot(0)*_eta_dot(2)*cos(_eta(1))*sin(_eta(0))
            +Ix*_eta_dot(2)*_eta_dot(1)*cos(_eta(0))*sin(_eta(1))
            -Iy*_eta_dot(2)*_eta_dot(1)*cos(_eta(0))*sin(_eta(1))
            -Iz*_eta_dot(2)*_eta_dot(1)*cos(_eta(0))*sin(_eta(1));

    alpha_1=(Iy*sin(_eta(0)))*((tau_hat_yaw-alpha_2)/(Iz*cos(_eta(0))))+alpha_3;
    
    
    _tau=((Iy*cos(_eta(0))+(Iy*((sin(_eta(0))*sin(_eta(0))))/cos(_eta(0))))*_tau_hat)+alpha_1;

    //cout<<"alpha="<<alpha_1<<endl;
    //cout<<"Errore_i="<<err_p_p_i<<endl;
    
};



void BI_CONTROLLER::input(){

double vel_rotor_1=0.0;
double vel_rotor_3=0.0;
double l=0.17;


//mav_msgs::ActuatorsPtr actuator_msg(new mav_msgs::Actuators);
std_msgs::Float64MultiArray vel_msg;
std_msgs::Float64MultiArray err_msg;
vel_msg.data.resize(4);
err_msg.data.resize(8);
ros::Rate rate(100); 


while(ros::ok()){
    position_control();
    roll_control();
    if(_first_odom==0) {
        _thrust=0.0;
        _tau=0.0;
        }
    else{    
    _thrust=_thrust;
    _tau=_tau;
    //tau_roll=tau_roll;
    }
    vel_rotor_1=sqrt(((l*_thrust)-_tau)/(2*l*ct));
    vel_rotor_3=sqrt(((l*_thrust)+_tau)/(2*l*ct));
    //saturazione
    if(vel_rotor_1>=850 && vel_rotor_3>=850){
        vel_rotor_1=850;
        vel_rotor_3=850;
    }
    else{
        vel_rotor_1=vel_rotor_1;
        vel_rotor_3=vel_rotor_3;
    }
    
    ref_rotor_vel<<vel_rotor_1,0,vel_rotor_3,0;
   

   for(int i=0;i<4;i++){
        vel_msg.data[i]=ref_rotor_vel(i);
        cout<<"Rotor_vel("<<i<<"): "<<ref_rotor_vel(i)<<endl;
    }
    _motor_vel_pub.publish(vel_msg);
    
    for(int i=0;i<3;i++){
        err_msg.data[i]=err_p(i);
    }
     for(int i=4;i<6;i++){
        err_msg.data[i]=err_v(i-4);
    }
    err_msg.data[7]=err_p_p;
    err_msg.data[8]=err_p_v;
    _error_pub.publish(err_msg);
    
    
    rate.sleep();
    ros::spinOnce();
}
}

void BI_CONTROLLER::run(){
    input();
    ros::spin();
}


int main(int argc,char** argv){
ros::init(argc,argv,"bi_controller");
BI_CONTROLLER bi;
bi.run();
return 0;
}
